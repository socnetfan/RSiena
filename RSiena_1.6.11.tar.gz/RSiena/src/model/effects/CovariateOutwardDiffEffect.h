/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: CovariateOutwardDiffEffect.h
 *
 * Description: This file contains the definition of the
 * CovariateOutwardDiffEffect class.
 *****************************************************************************/

#ifndef COVARIATEOUTWARDDIFFEFFECT_H_
#define COVARIATEOUTWARDDIFFEFFECT_H_

#include "CovariateDependentNetworkEffect.h"

namespace siena
{

/**
 * Network selection effect representing an outward directional preference
 * relative to a user-specified substantive reference point c.
 *
 * For a prospective tie i -> j, the contribution is
 *
 *     (z_i - c) * (z_j - z_i)
 *
 * The reference point c is read from the internal effect parameter.
 */
class CovariateOutwardDiffEffect : public CovariateDependentNetworkEffect
{
public:
	explicit CovariateOutwardDiffEffect(const EffectInfo * pEffectInfo);

protected:
	virtual double calculateContribution(int alter) const;
	virtual double tieStatistic(int alter);

private:
	//! User-specified substantive reference point.
	const double lreferencePoint;
};

}

#endif /* COVARIATEOUTWARDDIFFEFFECT_H_ */
