/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: TwoStepInToEffect.cpp
 *
 * Description: This file contains the implementation of the
 * TwoStepInToEffect class.
 *
 * This effect is defined for a dependent person-to-focus affiliation
 * network Y and a directed interpersonal network X.
 *
 * For ego i and focus A, the tie statistic is
 *
 *     sum_{j,k} x_{jk} x_{ki} y_{jA},
 *
 * with j != i.
 *
 * Thus, an affiliation y_{jA} contributes to ego i's tendency to affiliate
 * with A when there is a directed two-step interpersonal path
 *
 *     j -> k -> i.
 *
 * Multiple two-step paths are counted separately.
 *****************************************************************************/

#include <stdexcept>

#include "TwoStepInToEffect.h"
#include "network/Network.h"
#include "network/IncidentTieIterator.h"
#include "model/State.h"
#include "model/EffectInfo.h"

using namespace std;

namespace siena
{

/**
 * Constructor.
 */
TwoStepInToEffect::TwoStepInToEffect(const EffectInfo * pEffectInfo) :
	NetworkEffect(pEffectInfo),
	lpInterpersonalNetwork(0)
{
}


/**
 * Initializes this effect.
 *
 * The dependent network is the person-to-focus affiliation network.
 * interactionName1 identifies the directed interpersonal network.
 */
void TwoStepInToEffect::initialize(const Data * pData,
	State * pState,
	int period,
	Cache * pCache)
{
	NetworkEffect::initialize(pData, pState, period, pCache);

	string networkName = this->pEffectInfo()->interactionName1();
	this->lpInterpersonalNetwork = pState->pNetwork(networkName);

	if (!this->lpInterpersonalNetwork)
	{
		throw logic_error("Interpersonal network '" + networkName +
			"' expected for TwoStepInToEffect.");
	}
}


/**
 * Initializes this effect when a simulated state is supplied.
 */
void TwoStepInToEffect::initialize(const Data * pData,
	State * pState,
	State * pSimulatedState,
	int period,
	Cache * pCache)
{
	NetworkEffect::initialize(
		pData, pState, pSimulatedState, period, pCache);

	string networkName = this->pEffectInfo()->interactionName1();

	const State * pNetworkState = pSimulatedState ?
		pSimulatedState : pState;

	this->lpInterpersonalNetwork =
		pNetworkState->pNetwork(networkName);

	if (!this->lpInterpersonalNetwork)
	{
		throw logic_error("Interpersonal network '" + networkName +
			"' expected for TwoStepInToEffect.");
	}
}


/**
 * Counts directed two-step paths j -> k -> ego for which source actor j
 * is affiliated with the specified focus.
 *
 * Actor j == ego is excluded. Without this restriction, a reciprocal
 * interpersonal dyad ego <-> k would create a spurious "self-influence"
 * contribution through ego's own affiliation y_{ego,A}.
 */
double TwoStepInToEffect::twoStepCount(int ego,
	int focus,
	const Network * pAffiliationNetwork) const
{
	double statistic = 0;

	// k -> ego
	for (IncidentTieIterator iterK =
			this->lpInterpersonalNetwork->inTies(ego);
		iterK.valid();
		iterK.next())
	{
		int k = iterK.actor();

		// j -> k
		for (IncidentTieIterator iterJ =
				this->lpInterpersonalNetwork->inTies(k);
			iterJ.valid();
			iterJ.next())
		{
			int j = iterJ.actor();

			// Exclude ego as the source of its own affiliation.
			if (j != ego &&
				pAffiliationNetwork->tieValue(j, focus) != 0)
			{
				statistic += 1;
			}
		}
	}

	return statistic;
}


/**
 * Calculates the contribution of the prospective affiliation tie
 * ego -> alter (where alter is a focus).
 *
 * Since the two-step count excludes j == ego, the count does not depend
 * on the current value of y_{ego,alter}. Hence it is exactly
 *
 *     s_i(Y + iA) - s_i(Y - iA).
 */
double TwoStepInToEffect::calculateContribution(int alter) const
{
	return this->twoStepCount(
		this->ego(), alter, this->pNetwork());
}


/**
 * The contribution of the affiliation tie from the implicit ego to the
 * specified focus to the statistic.
 */
double TwoStepInToEffect::tieStatistic(int alter)
{
	return this->twoStepCount(
		this->ego(), alter, this->pNetwork());
}


/**
 * The contribution of ego to the estimation statistic.
 *
 * This explicit implementation ensures that the affiliation network
 * supplied for statistic calculation is used when checking y_{jA}.
 */
double TwoStepInToEffect::egoStatistic(int ego,
	const Network * pNetwork)
{
	double statistic = 0;

	for (IncidentTieIterator iterA = pNetwork->outTies(ego);
		iterA.valid();
		iterA.next())
	{
		int focus = iterA.actor();

		statistic += this->twoStepCount(
			ego, focus, pNetwork);
	}

	return statistic;
}

}
