/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: DirectionalSonadaEffect.h
 *
 * Description: SONADA behavior influence effects distinguishing
 * non-reciprocal outgoing, non-reciprocal incoming, and reciprocal ties.
 *****************************************************************************/

#ifndef DIRECTIONALSONADAEFFECT_H_
#define DIRECTIONALSONADAEFFECT_H_

#include "NetworkDependentBehaviorEffect.h"

namespace siena
{

class Network;

/**
 * Relational category used to define ego's influence neighborhood.
 *
 * SONADA_OUT_ONLY:
 *     ego -> alter, alter -/-> ego
 *
 * SONADA_IN_ONLY:
 *     alter -> ego, ego -/-> alter
 *
 * SONADA_RECIPROCAL:
 *     ego <-> alter
 */
enum SonadaRelationType
{
	SONADA_OUT_ONLY = 1,
	SONADA_IN_ONLY = 2,
	SONADA_RECIPROCAL = 3
};


class DirectionalSonadaEffect :
	public NetworkDependentBehaviorEffect
{
public:
	DirectionalSonadaEffect(
		const EffectInfo * pEffectInfo,
		bool average,
		bool alterPopularity,
		bool egoPopularity,
		SonadaRelationType relationType);

	virtual double calculateChangeContribution(
		int actor,
		int difference);

	virtual double egoEndowmentStatistic(
		int ego,
		const int * difference,
		double * currentValues);

	virtual double egoStatistic(
		int ego,
		double * currentValues);

private:
	bool laverage;
	bool lalterPopularity;
	bool legoPopularity;

	SonadaRelationType lrelationType;

	bool relevantAlter(
		const Network * pNetwork,
		int ego,
		int alter) const;

	int relevantAlterCount(
		const Network * pNetwork,
		int ego) const;
};

}

#endif /* DIRECTIONALSONADAEFFECT_H_ */
