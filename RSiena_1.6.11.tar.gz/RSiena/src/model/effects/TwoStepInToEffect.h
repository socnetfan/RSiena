/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: TwoStepInToEffect.h
 *
 * Description: This file contains the definition of the
 * TwoStepInToEffect class.
 *****************************************************************************/

#ifndef TWOSTEPINTOEFFECT_H_
#define TWOSTEPINTOEFFECT_H_

#include "NetworkEffect.h"

namespace siena
{

class Network;

/**
 * Effect for directed two-step interpersonal diffusion into ego.
 *
 * The dependent network Y is a person-to-focus affiliation network.
 * The interacting network X is a directed interpersonal network.
 *
 * For ego i and focus A:
 *
 *     s_{iA} = sum_{j,k} x_{jk} x_{ki} y_{jA},   j != i.
 *
 * The configuration is therefore
 *
 *     j -> k -> i
 *
 * together with j -> A, and the effect evaluates whether ego i tends
 * to affiliate with focus A when actors reaching ego through directed
 * two-step interpersonal paths are already affiliated with A.
 */
class TwoStepInToEffect : public NetworkEffect
{
public:
	explicit TwoStepInToEffect(const EffectInfo * pEffectInfo);

	virtual void initialize(const Data * pData,
		State * pState,
		int period,
		Cache * pCache);

	virtual void initialize(const Data * pData,
		State * pState,
		State * pSimulatedState,
		int period,
		Cache * pCache);

protected:
	virtual double calculateContribution(int alter) const;
	virtual double tieStatistic(int alter);
	virtual double egoStatistic(int ego, const Network * pNetwork);

private:
	//! Directed interpersonal network X.
	const Network * lpInterpersonalNetwork;

	/**
	 * Counts paths j -> k -> ego whose source j is affiliated with focus.
	 */
	double twoStepCount(int ego,
		int focus,
		const Network * pAffiliationNetwork) const;
};

}

#endif /* TWOSTEPINTOEFFECT_H_ */
