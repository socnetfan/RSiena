/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: CovariateOutwardDiffEffect.cpp
 *
 * Description: This file contains the implementation of the
 * CovariateOutwardDiffEffect class.
 *
 * The effect statistic for a prospective tie i -> j is
 *
 *     (z_i - c) * (z_j - z_i)
 *
 * where c is a user-specified substantive reference point supplied through
 * the internal effect parameter.
 *****************************************************************************/

#include "CovariateOutwardDiffEffect.h"
#include "model/EffectInfo.h"

namespace siena
{

/**
 * Constructor.
 *
 * @param[in] pEffectInfo the effect descriptor. The internal effect parameter
 *                        is used as the substantive reference point c.
 */
CovariateOutwardDiffEffect::CovariateOutwardDiffEffect(
	const EffectInfo * pEffectInfo) :
	CovariateDependentNetworkEffect(pEffectInfo),
	lreferencePoint(pEffectInfo->internalEffectParameter())
{
}


/**
 * Calculates the contribution of a tie flip to the given actor.
 *
 * For ego i and alter j:
 *
 *     (z_i - c) * (z_j - z_i)
 */
double CovariateOutwardDiffEffect::calculateContribution(int alter) const
{
	double egoValue = this->value(this->ego());
	double alterValue = this->value(alter);

	return (egoValue - this->lreferencePoint) *
		(alterValue - egoValue);
}


/**
 * The contribution of the tie from the implicit ego to the given alter
 * to the statistic. It is assumed that preprocessEgo(ego) has been
 * called before.
 */
double CovariateOutwardDiffEffect::tieStatistic(int alter)
{
	double statistic = 0;

	if (!(this->missing(alter) || this->missing(this->ego())))
	{
		double egoValue = this->value(this->ego());
		double alterValue = this->value(alter);

		statistic =
			(egoValue - this->lreferencePoint) *
			(alterValue - egoValue);
	}

	return statistic;
}

}
