/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: DirectionalSonadaEffect.cpp
 *
 * Description: SONADA behavior influence effects distinguishing
 * non-reciprocal outgoing, non-reciprocal incoming, and reciprocal ties.
 *****************************************************************************/

#include <cstdlib>
#include <cmath>
#include <stdexcept>

#include "DirectionalSonadaEffect.h"
#include "network/Network.h"
#include "network/IncidentTieIterator.h"
#include "model/variables/NetworkVariable.h"
#include "model/variables/BehaviorVariable.h"

using namespace std;

namespace siena
{

DirectionalSonadaEffect::DirectionalSonadaEffect(
	const EffectInfo * pEffectInfo,
	bool average,
	bool alterPopularity,
	bool egoPopularity,
	SonadaRelationType relationType) :
		NetworkDependentBehaviorEffect(pEffectInfo)
{
	this->laverage = average;
	this->lalterPopularity = alterPopularity;
	this->legoPopularity = egoPopularity;
	this->lrelationType = relationType;
}


/**
 * Returns whether alter belongs to the relational category
 * defining ego's influence neighborhood.
 */
bool DirectionalSonadaEffect::relevantAlter(
	const Network * pNetwork,
	int ego,
	int alter) const
{
	bool outTie = (pNetwork->tieValue(ego, alter) != 0);
	bool inTie  = (pNetwork->tieValue(alter, ego) != 0);

	if (this->lrelationType == SONADA_OUT_ONLY)
	{
		return outTie && !inTie;
	}
	else if (this->lrelationType == SONADA_IN_ONLY)
	{
		return inTie && !outTie;
	}
	else if (this->lrelationType == SONADA_RECIPROCAL)
	{
		return outTie && inTie;
	}

	return false;
}


/**
 * Counts alters belonging to the selected relational category.
 *
 * This count is used as the denominator for average SONADA.
 */
int DirectionalSonadaEffect::relevantAlterCount(
	const Network * pNetwork,
	int ego) const
{
	int count = 0;

	if (this->lrelationType == SONADA_IN_ONLY)
	{
		for (IncidentTieIterator iter = pNetwork->inTies(ego);
			 iter.valid();
			 iter.next())
		{
			int j = iter.actor();

			// j -> ego exists by construction of inTies().
			// Keep only cases where ego -> j does not exist.
			if (pNetwork->tieValue(ego, j) == 0)
			{
				count++;
			}
		}
	}
	else
	{
		for (IncidentTieIterator iter = pNetwork->outTies(ego);
			 iter.valid();
			 iter.next())
		{
			int j = iter.actor();
			bool reciprocal =
				(pNetwork->tieValue(j, ego) != 0);

			if (this->lrelationType == SONADA_OUT_ONLY &&
				!reciprocal)
			{
				count++;
			}
			else if (
				this->lrelationType == SONADA_RECIPROCAL &&
				reciprocal)
			{
				count++;
			}
		}
	}

	return count;
}


/**
 * Calculates the change in the statistic if actor changes
 * behavior by "difference".
 *
 * SONADA:
 *
 *   s_i = - sum_j |z_i - z_j|
 *
 * or, for the average version,
 *
 *   s_i = - (1 / n_i) sum_j |z_i - z_j|
 *
 * where j belongs only to the selected relational category.
 */
double DirectionalSonadaEffect::calculateChangeContribution(
	int actor,
	int difference)
{
	double contribution = 0;
	const Network * pNetwork = this->pNetwork();

	if (!pNetwork->isOneMode())
	{
		throw runtime_error(
			"DirectionalSonadaEffect requires a one-mode network.");
	}

	int neighborCount =
		this->relevantAlterCount(pNetwork, actor);

	if (neighborCount > 0)
	{
		int oldValue = this->value(actor);
		int newValue = oldValue + difference;
		int totalChange = 0;

		if (this->lrelationType == SONADA_IN_ONLY)
		{
			for (IncidentTieIterator iter =
					pNetwork->inTies(actor);
				 iter.valid();
				 iter.next())
			{
				int j = iter.actor();

				// Incoming-only:
				// j -> actor, but actor -/-> j.
				if (pNetwork->tieValue(actor, j) != 0)
				{
					continue;
				}

				int alterValue = this->value(j);

				int change =
					abs(oldValue - alterValue) -
					abs(newValue - alterValue);

				if (this->lalterPopularity)
				{
					change *= pNetwork->inDegree(j);
				}

				totalChange += change;
			}
		}
		else
		{
			for (IncidentTieIterator iter =
					pNetwork->outTies(actor);
				 iter.valid();
				 iter.next())
			{
				int j = iter.actor();

				bool reciprocal =
					(pNetwork->tieValue(j, actor) != 0);

				if (this->lrelationType ==
						SONADA_OUT_ONLY &&
					reciprocal)
				{
					continue;
				}

				if (this->lrelationType ==
						SONADA_RECIPROCAL &&
					!reciprocal)
				{
					continue;
				}

				int alterValue = this->value(j);

				int change =
					abs(oldValue - alterValue) -
					abs(newValue - alterValue);

				if (this->lalterPopularity)
				{
					change *= pNetwork->inDegree(j);
				}

				totalChange += change;
			}
		}

		contribution = totalChange;

		if (this->laverage)
		{
			contribution =
				((double) totalChange) / neighborCount;
		}

		if (this->legoPopularity)
		{
			contribution *=
				pNetwork->inDegree(actor);
		}
	}

	return contribution;
}


/**
 * Returns the actor-specific statistic for the current
 * behavior values.
 */
double DirectionalSonadaEffect::egoStatistic(
	int ego,
	double * currentValues)
{
	const Network * pNetwork = this->pNetwork();

	if (!pNetwork->isOneMode())
	{
		throw runtime_error(
			"DirectionalSonadaEffect requires a one-mode network.");
	}

	double statistic = 0;
	int neighborCount = 0;

	if (this->lrelationType == SONADA_IN_ONLY)
	{
		for (IncidentTieIterator iter = pNetwork->inTies(ego);
			 iter.valid();
			 iter.next())
		{
			int j = iter.actor();

			if (pNetwork->tieValue(ego, j) != 0)
			{
				continue;
			}

			if (!this->missing(this->period(), j) &&
				!this->missing(this->period() + 1, j))
			{
				double tt =
					-fabs(currentValues[ego] -
						  currentValues[j]);

				if (this->lalterPopularity)
				{
					tt *= pNetwork->inDegree(j);
				}

				statistic += tt;
				neighborCount++;
			}
		}
	}
	else
	{
		for (IncidentTieIterator iter = pNetwork->outTies(ego);
			 iter.valid();
			 iter.next())
		{
			int j = iter.actor();

			bool reciprocal =
				(pNetwork->tieValue(j, ego) != 0);

			if (this->lrelationType ==
					SONADA_OUT_ONLY &&
				reciprocal)
			{
				continue;
			}

			if (this->lrelationType ==
					SONADA_RECIPROCAL &&
				!reciprocal)
			{
				continue;
			}

			if (!this->missing(this->period(), j) &&
				!this->missing(this->period() + 1, j))
			{
				double tt =
					-fabs(currentValues[ego] -
						  currentValues[j]);

				if (this->lalterPopularity)
				{
					tt *= pNetwork->inDegree(j);
				}

				statistic += tt;
				neighborCount++;
			}
		}
	}

	if (this->laverage && neighborCount > 0)
	{
		statistic /= neighborCount;
	}

	if (this->legoPopularity)
	{
		statistic *= pNetwork->inDegree(ego);
	}

	return statistic;
}


/**
 * Endowment statistic.
 *
 * This follows the logic of the existing SonadaEffect,
 * but restricts alters to the selected relational category.
 */
double DirectionalSonadaEffect::egoEndowmentStatistic(
	int ego,
	const int * difference,
	double * currentValues)
{
	if (this->lalterPopularity)
	{
		throw runtime_error(
			string("endowmentStatistic not implemented for ") +
			"directional SONADA x alter popularity effect.");
	}

	const Network * pNetwork = this->pNetwork();

	if (!pNetwork->isOneMode())
	{
		throw runtime_error(
			"DirectionalSonadaEffect requires a one-mode network.");
	}

	double statistic = 0;

	if (!this->missing(this->period(), ego) &&
		!this->missing(this->period() + 1, ego))
	{
		if (difference[ego] > 0)
		{
			int relationCount =
				this->relevantAlterCount(pNetwork, ego);

			if (relationCount > 0)
			{
				double thisStatistic = 0;

				// Statistic using the current behavior state.
				if (this->lrelationType == SONADA_IN_ONLY)
				{
					for (IncidentTieIterator iter =
							pNetwork->inTies(ego);
						 iter.valid();
						 iter.next())
					{
						int j = iter.actor();

						if (pNetwork->tieValue(ego, j) != 0)
						{
							continue;
						}

						if (!this->missing(this->period(), j) &&
							!this->missing(this->period() + 1, j))
						{
							double alterValue =
								currentValues[j];

							thisStatistic +=
								iter.value() *
								(0.0 -
								 fabs(alterValue -
									  currentValues[ego]));
						}
					}
				}
				else
				{
					for (IncidentTieIterator iter =
							pNetwork->outTies(ego);
						 iter.valid();
						 iter.next())
					{
						int j = iter.actor();

						bool reciprocal =
							(pNetwork->tieValue(j, ego) != 0);

						if (this->lrelationType ==
								SONADA_OUT_ONLY &&
							reciprocal)
						{
							continue;
						}

						if (this->lrelationType ==
								SONADA_RECIPROCAL &&
							!reciprocal)
						{
							continue;
						}

						if (!this->missing(this->period(), j) &&
							!this->missing(this->period() + 1, j))
						{
							double alterValue =
								currentValues[j];

							thisStatistic +=
								iter.value() *
								(0.0 -
								 fabs(alterValue -
									  currentValues[ego]));
						}
					}
				}

				if (this->laverage)
				{
					thisStatistic /= relationCount;
				}

				if (this->legoPopularity)
				{
					thisStatistic *=
						pNetwork->inDegree(ego);
				}

				statistic = thisStatistic;

				// Recalculate using current state plus
				// the behavior differences.
				thisStatistic = 0;

				if (this->lrelationType == SONADA_IN_ONLY)
				{
					for (IncidentTieIterator iter =
							pNetwork->inTies(ego);
						 iter.valid();
						 iter.next())
					{
						int j = iter.actor();

						if (pNetwork->tieValue(ego, j) != 0)
						{
							continue;
						}

						if (!this->missing(this->period(), j) &&
							!this->missing(this->period() + 1, j))
						{
							double alterValue =
								currentValues[j] +
								difference[j];

							thisStatistic +=
								iter.value() *
								(0.0 -
								 fabs(alterValue -
									(difference[ego] +
									 currentValues[ego])));
						}
					}
				}
				else
				{
					for (IncidentTieIterator iter =
							pNetwork->outTies(ego);
						 iter.valid();
						 iter.next())
					{
						int j = iter.actor();

						bool reciprocal =
							(pNetwork->tieValue(j, ego) != 0);

						if (this->lrelationType ==
								SONADA_OUT_ONLY &&
							reciprocal)
						{
							continue;
						}

						if (this->lrelationType ==
								SONADA_RECIPROCAL &&
							!reciprocal)
						{
							continue;
						}

						if (!this->missing(this->period(), j) &&
							!this->missing(this->period() + 1, j))
						{
							double alterValue =
								currentValues[j] +
								difference[j];

							thisStatistic +=
								iter.value() *
								(0.0 -
								 fabs(alterValue -
									(difference[ego] +
									 currentValues[ego])));
						}
					}
				}

				if (this->laverage)
				{
					thisStatistic /= relationCount;
				}

				if (this->legoPopularity)
				{
					thisStatistic *=
						pNetwork->inDegree(ego);
				}

				statistic -= thisStatistic;
			}
		}
	}

	return statistic;
}

}
