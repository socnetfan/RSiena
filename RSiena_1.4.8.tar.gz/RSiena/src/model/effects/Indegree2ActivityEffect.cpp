/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: Indegree2ActivityEffect.cpp
 *
 * Description: This file contains the implementation of the
 * Indegree2ActivityEffect class.
 *****************************************************************************/

#include <cmath>

#include "Indegree2ActivityEffect.h"
#include "network/Network.h"
#include "model/variables/NetworkVariable.h"

namespace siena
{

/**
 * Constructor.
 */
Indegree2ActivityEffect::Indegree2ActivityEffect(
	const EffectInfo * pEffectInfo) : NetworkEffect(pEffectInfo)
{
}


/**
 * Calculates the contribution of a tie flip to the given actor.
 */
double Indegree2ActivityEffect::calculateContribution(int alter) const
{
    // Current in-degree
	int d =	this->pNetwork()->inDegree(this->ego());
	
	double change = d * d;

	return change;
}


/**
 * The contribution of the tie from the implicit ego to the given alter
 * to the statistic. It is assumed that preprocessEgo(ego) has been
 * called before.
 */
double Indegree2ActivityEffect::tieStatistic(int alter)
{
	const Network * pNetwork = this->pNetwork();
	int inDegree = pNetwork->inDegree(this->ego());
	double statistic = inDegree * inDegree;
	return statistic;
}

}
