/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: EgoSimEffect.h
 *
 * Description: This file contains the definition of the
 * EgoSimEffect class.
 *****************************************************************************/

#ifndef EGOSIMEFFECT_H_
#define EGOSIMEFFECT_H_

#include "NetworkDependentBehaviorEffect.h"

namespace siena
{

/**
 * Ego sim effect defined as the product of the ego with the average
 * of its in-coming neighbors (with respect to a certain network).
 */
class EgoSimEffect : public NetworkDependentBehaviorEffect
{
public:
	EgoSimEffect(const EffectInfo * pEffectInfo);

	virtual double calculateChangeContribution(int actor,
		int difference);
	virtual double egoEndowmentStatistic(int ego, const int * difference,
		double * currentValues);
	virtual double egoStatistic(int ego, double * currentValues);
};

}

#endif /*EGOSIMEFFECT_H_*/
