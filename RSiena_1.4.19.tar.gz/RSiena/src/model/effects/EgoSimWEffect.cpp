/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: EgoSimWEffect.cpp
 *
 * Description: This file contains the implementation of the
 * EgoSimWEffect class.
 *****************************************************************************/
#include <cstdlib>
#include <cmath>
#include "EgoSimWEffect.h"
#include "data/Data.h"
#include "network/Network.h"
#include "network/IncidentTieIterator.h"
#include "model/EffectInfo.h"
#include "model/variables/BehaviorVariable.h"

namespace siena
{

/**
 * Constructor.
 */
EgoSimWEffect::EgoSimWEffect(
	const EffectInfo * pEffectInfo) :
		DyadicCovariateAndNetworkBehaviorEffect(pEffectInfo)
{
	this->lpar2 = (pEffectInfo->internalEffectParameter() >= 2);
	// specifies type of denominator
}


/**
 * Calculates the change in the statistic corresponding to this effect if
 * the given actor would change his behavior by the given amount.
 */
double EgoSimWEffect::calculateChangeContribution(int actor,
	int difference)
{
	double contribution = 0;
	const Network * pNetwork = this->pNetwork();

	if (pNetwork->inDegree(actor) > 0)
	{
		// The formula for the ego similarity W effect:
		// s_i(x) = avg(w(i,h)* -1 * abs(v_i - v_h)) over all incoming neighbors
		// h of i.

		int oldValue = this->value(actor);
		int newValue = oldValue + difference;
		int totalCount = 0;
		double totalChange = 0;
		double totalWeightValue = 0;

		for (IncidentTieIterator iter = pNetwork->inTies(actor);
			iter.valid();
			iter.next())
		{
			int h = iter.actor();
			int alterValue = this->value(h);
			double dycova = this->dycoValue(actor, h);
			double change = dycova *
				(abs(oldValue - alterValue) - abs(newValue - alterValue));
			if (dycova != 0.0) totalCount++;
			if (lpar2)
			{
				totalWeightValue += dycova;
			}
			else
			{
				totalWeightValue += 1;
			}

			totalChange += change;
		}

		contribution = ((double) totalChange)/pNetwork->inDegree(actor);

		if ((totalCount > 0))
		{
			contribution /= totalWeightValue;
		}

	}
	return contribution;
}


/**
 * Returns the statistic corresponding to the given ego with respect to the
 * given values of the behavior variable.
 */
double EgoSimWEffect::egoStatistic(int ego, double * currentValues)
{
	const Network * pNetwork = this->pNetwork();

	double statistic = 0;
	double neighborCount = 0;
	double totalWeightValue = 0;
	int totalCount = 0;

	for (IncidentTieIterator iter = pNetwork->inTies(ego);
		 iter.valid();
		 iter.next())
	{
		int h = iter.actor();

		if (!this->missing(this->period(), h) &&
			!this->missing(this->period() + 1, h))
		{
			double dycova = this->dycoValue(ego, h);
			double tieStatistic = dycova * fabs(currentValues[ego]-currentValues[h]);
			statistic += tieStatistic;
			neighborCount++;
			if (dycova != 0.0) totalCount++;
			if (lpar2)
			{
				totalWeightValue += dycova;
			}
			else
			{
				totalWeightValue += 1;
			}
		}
	}
	statistic = -1 * statistic/neighborCount;
	if ((totalCount > 0))
	{
		statistic /= totalWeightValue;
	}

	return statistic;
}

}
