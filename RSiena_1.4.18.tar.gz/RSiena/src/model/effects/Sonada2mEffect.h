/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: Sonada2mEffect.h
 *
 * Description: This file contains the definition of the
 * Sonada2mEffect class.
 *****************************************************************************/

#ifndef SONADA2MEFFECT_H_
#define SONADA2MEFFECT_H_

#include "DyadicCovariateAndNetworkBehaviorEffect.h"

namespace siena
{

/**
 * This class implements several behavior effects related to sonada 2mode similarity 
 * - Sonada 2mode similarity 
 */
class Sonada2mEffect : public DyadicCovariateAndNetworkBehaviorEffect
{
public:
	Sonada2mEffect(const EffectInfo * pEffectInfo);

	virtual double calculateChangeContribution(int actor,
		int difference);
	virtual double egoStatistic(int ego, double * currentValues);

};

}

#endif /*SONADA2MEFFECT_H_*/
