/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: EgoSimEffect.cpp
 *
 * Description: This file contains the implementation of the
 * EgoSimEffect class.
 *****************************************************************************/

#include <cmath>
#include "EgoSimEffect.h"
#include "network/Network.h"
#include "network/IncidentTieIterator.h"

#include "model/variables/NetworkVariable.h"
#include "model/variables/BehaviorVariable.h"

namespace siena
{

/**
 * Constructor.
 */
EgoSimEffect::EgoSimEffect(
	const EffectInfo * pEffectInfo) :
		NetworkDependentBehaviorEffect(pEffectInfo)
{
}


/**
 * Calculates the change in the statistic corresponding to this effect if
 * the given actor would change his behavior by the given amount.
 */
double EgoSimEffect::calculateChangeContribution(int actor,
	int difference)
{
	double contribution = 0;
	const Network * pNetwork = this->pNetwork();

	if (pNetwork->inDegree(actor) > 0)
	{
		// The formula for the effect:
		// s_i(x) = -1 * abs(v_i - v_h) over all neighbors h of i.
		// We need to calculate the change delta in s_i(x), if we changed
		// v_i to v_i + d (d being the given amount of change in v_i).
		// This is abs(v_i - v_h)-abs(v_i + d - v_h).
		// This is what is calculated below.

		int oldValue = this->value(actor);
		int newValue = oldValue + difference;
		int totalChange = 0;

		for (IncidentTieIterator iter = pNetwork->inTies(actor);
			iter.valid();
			iter.next())
		{
			int h = iter.actor();
			int alterValue = this->value(h);
			int change = fabs(oldValue - alterValue) - fabs(newValue - alterValue);
			totalChange += change;
		}
		contribution = ((double) totalChange)/pNetwork->inDegree(actor);
	}

	return contribution;
}


/**
 * Returns the statistic corresponding to the given ego with respect to the
 * given values of the behavior variable.
 */
double EgoSimEffect::egoStatistic(int i, double * currentValues)
{
	double statistic = 0;
	double tt = 0;
	double neighborCount = 0;
	const Network * pNetwork = this->pNetwork();
	
	for (IncidentTieIterator iter = pNetwork->inTies(i);
		 iter.valid();
		 iter.next())
	{
		int h = iter.actor();

		if (!this->missing(this->period(), h) &&
			!this->missing(this->period() + 1, h))
		{
			tt += fabs(currentValues[i]-currentValues[h]);
			neighborCount++;
		}

	}
	
	if (neighborCount > 0)
	{
		statistic = -1 * tt / neighborCount;
	}

	return statistic;
}




/**
 * Returns the statistic corresponding to the given ego as part of
 * the endowment function with respect to the initial values of a
 * behavior variable and the current values.
 */
double EgoSimEffect::egoEndowmentStatistic(int ego, const int * difference,
	double * currentValues)
{
	double statistic = 0;
	const Network * pNetwork = this->pNetwork();

	if (!this->missing(this->period(), ego) &&
		!this->missing(this->period() + 1, ego))
	{
		if (difference[ego] > 0)
		{
			if (pNetwork->inDegree(ego))
			{
				double thisStatistic = 0;

				for (IncidentTieIterator iter = pNetwork->inTies(ego);
					 iter.valid();
					 iter.next())
				{
					if (!this->missing(this->period(), iter.actor()) &&
						!this->missing(this->period() + 1, iter.actor()))
					{
						double alterValue = currentValues[iter.actor()];
						thisStatistic += iter.value() *
							(0.0 - fabs(alterValue - currentValues[ego]));
					}
				}

				statistic = thisStatistic/pNetwork->inDegree(ego);

			}
		}
	}

	return statistic;
}

}
