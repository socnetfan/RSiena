/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: SonadaEffect.cpp
 *
 * Description: This file contains the implementation of the
 * SonadaEffect class.
 *****************************************************************************/
#include <cstdlib>
#include <cmath>
#include <stdexcept>
#include "SonadaEffect.h"
#include "network/Network.h"
#include "network/IncidentTieIterator.h"
#include "model/variables/NetworkVariable.h"
#include "model/variables/BehaviorVariable.h"

using namespace std;

namespace siena
{

/**
 * Constructor.
 * @param[in] average indicates if one of the average effects is required
 * @param[in] alterPopularity indicates if the similarity scores have to
 * be multiplied by the in-degrees of alters
 */
SonadaEffect::SonadaEffect(
	const EffectInfo * pEffectInfo,
	bool average,
	bool alterPopularity,
	bool egoPopularity) :
		NetworkDependentBehaviorEffect(pEffectInfo)
{
	this->laverage = average;
	this->lalterPopularity = alterPopularity;
	this->legoPopularity = egoPopularity;
}


/**
 * Calculates the change in the statistic corresponding to this effect if
 * the given actor would change his behavior by the given amount.
 */
double SonadaEffect::calculateChangeContribution(int actor,
	int difference)
{
	double contribution = 0;
	const Network * pNetwork = this->pNetwork();

	if (pNetwork->outDegree(actor) > 0)
	{
		// The formula for the effect:
		// s_i(x) = -1 * abs(v_i - v_j) over all neighbors j of i.
		// We need to calculate the change delta in s_i(x), if we changed
		// v_i to v_i + d (d being the given amount of change in v_i).
		// This is abs(v_i - v_j)-abs(v_i + d - v_j).
		// This is what is calculated below.

		int oldValue = this->value(actor);
		int newValue = oldValue + difference;
		int totalChange = 0;

		for (IncidentTieIterator iter = pNetwork->outTies(actor);
			iter.valid();
			iter.next())
		{
			int j = iter.actor();
			int alterValue = this->value(j);
			int change = abs(oldValue - alterValue) - abs(newValue - alterValue);

			if (this->lalterPopularity)
			{
				change *= pNetwork->inDegree(j);
			}

			totalChange += change;
		}
		
		contribution = totalChange;

		if (this->laverage)
		{
			contribution = ((double) totalChange)/pNetwork->outDegree(actor);
		}

		if (this->legoPopularity)
		{
			contribution *= pNetwork->inDegree(actor);
		}
	}

	return contribution;
}


/**
 * Returns the statistic corresponding to the given ego with respect to the
 * given values of the behavior variable.
 */
double SonadaEffect::egoStatistic(int ego,
	double * currentValues)
{
	const Network * pNetwork = this->pNetwork();

	double statistic = 0;
	double tt = 0;
	double neighborCount = 0;

	for (IncidentTieIterator iter = pNetwork->outTies(ego);
		 iter.valid();
		 iter.next())
	{
		int j = iter.actor();

		if (!this->missing(this->period(), j) &&
			!this->missing(this->period() + 1, j))
		{
		    if (currentValues[ego] > currentValues[j])
		    {
		        tt = currentValues[j]-currentValues[ego];
	        }
		    else
		    {
		        tt = currentValues[ego]-currentValues[j];
		    }	

			if (this->lalterPopularity)
			{
				tt *= pNetwork->inDegree(j);
			}

			statistic += tt;
			neighborCount++;
		}
	}

	if (this->laverage && neighborCount > 0)
	{
		statistic /= neighborCount;
	}

	if (this->legoPopularity)
	{
		statistic *= pNetwork->inDegree(ego);
	}

	return statistic;
}


/**
 * Returns the statistic corresponding to the given ego as part of
 * the endowment function with respect to the initial values of a
 * behavior variable and the current values.
 */
double SonadaEffect::egoEndowmentStatistic(int ego, const int * difference,
	double * currentValues)
{
	if (this->lalterPopularity)
	{
		throw runtime_error(string("endowmentStatistic not implemented for") +
			"average similarity x popularity alter effect and " +
			"total similarity x popularity alter effect.");
	}

	double statistic = 0;
	const Network * pNetwork = this->pNetwork();

	if (!this->missing(this->period(), ego) &&
		!this->missing(this->period() + 1, ego))
	{
		if (difference[ego] > 0)
		{
			if (pNetwork->outDegree(ego))
			{
				double thisStatistic = 0;

				for (IncidentTieIterator iter = pNetwork->outTies(ego);
					 iter.valid();
					 iter.next())
				{
					if (!this->missing(this->period(), iter.actor()) &&
						!this->missing(this->period() + 1, iter.actor()))
					{
						double alterValue = currentValues[iter.actor()];
						thisStatistic += iter.value() *
							(0.0 - fabs(alterValue - currentValues[ego]));
					}
				}

				if (this->laverage)
				{
					thisStatistic /= pNetwork->outDegree(ego);
				}

				if (this->legoPopularity)
				{
					thisStatistic *= pNetwork->inDegree(ego);
				}
				statistic = thisStatistic;

				// do the same using the current state plus difference
				// in i's value rather than current state and subtract it.
				// not sure whether this is correct.

				thisStatistic = 0;

				for (IncidentTieIterator iter = pNetwork->outTies(ego);
					 iter.valid();
					 iter.next())
				{
					if (!this->missing(this->period(), iter.actor()) &&
						!this->missing(this->period() + 1, iter.actor()))
					{
						double alterValue = currentValues[iter.actor()] +
							difference[iter.actor()];
						thisStatistic += iter.value() *
							(0.0 - fabs(alterValue - (difference[ego] + currentValues[ego])));
					}
				}

				if (this->laverage)
				{
					thisStatistic /= pNetwork->outDegree(ego);
				}
				if (this->legoPopularity)
				{
					thisStatistic *= pNetwork->inDegree(ego);
				}

				statistic -= thisStatistic;
			}
		}
	}

	return statistic;
}

}
