/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: ReciprocatedSonadaEffect.h
 *
 * Description: This file contains the definition of the
 * IndegreeEffect class.
 *****************************************************************************/

#ifndef RECIPROCATEDSONADAEFFECT_H_
#define RECIPROCATEDSONADAEFFECT_H_

#include "NetworkDependentBehaviorEffect.h"

namespace siena
{

/**
 * This class implements several behavior effects related to SONADA similarity
 * and reciprocity (see manual):
 * - SONADA similarity x reciprocity
 * - SONADA similarity x popularity alter x reciprocity
 */
class ReciprocatedSonadaEffect : public NetworkDependentBehaviorEffect
{
public:
	ReciprocatedSonadaEffect(const EffectInfo * pEffectInfo,
		bool average,
		bool alterPopularity);

	virtual double calculateChangeContribution(int actor,
		int difference);
	virtual double egoStatistic(int ego, double * currentValues);

private:
	bool laverage;
	bool lalterPopularity;
};

}

#endif /*RECIPROCATEDSONADAEFFECT_H_*/

