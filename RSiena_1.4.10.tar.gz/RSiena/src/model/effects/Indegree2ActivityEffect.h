/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: Indegree2ActivityEffect.h
 *
 * Description: This file contains the definition of the
 * Indegree2ActivityEffect class.
 *****************************************************************************/

#ifndef INDEGREE2ACTIVITYEFFECT_H_
#define INDEGREE2ACTIVITYEFFECT_H_

#include "NetworkEffect.h"

namespace siena
{

/**
 * This class defines the indegree^2 activity effect defined by
 * s_i(x)= x_{+i}^2 x_{i+}. The corresponding statistic is
 * the sum of indegree^2 x outdegree products over all actors.
 */
class Indegree2ActivityEffect : public NetworkEffect
{
public:
	Indegree2ActivityEffect(const EffectInfo * pEffectInfo);

	virtual double calculateContribution(int alter) const;

protected:
	virtual double tieStatistic(int alter);

};

}

#endif /*INDEGREE2ACTIVITYEFFECT_H_*/
