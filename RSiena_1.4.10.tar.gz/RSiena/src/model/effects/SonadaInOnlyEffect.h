/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: SonadaInOnlyEffect.h
 *
 * Description: This file contains the definition of the
 * SonadaInOnlyEffect class.
 *****************************************************************************/

#ifndef SONADAINONLYEFFECT_H_
#define SONADAINONLYEFFECT_H_

#include "NetworkDependentBehaviorEffect.h"

namespace siena
{

/**
 * This class implements several behavior effects related to similarity
 * (see manual):
 * - Sonada Unrecip similarity
 */
class SonadaInOnlyEffect : public NetworkDependentBehaviorEffect
{
public:
	SonadaInOnlyEffect(const EffectInfo * pEffectInfo);

	virtual double calculateChangeContribution(int actor,
		int difference);
	virtual double egoEndowmentStatistic(int ego, const int * difference,
		double * currentValues);
	virtual double egoStatistic(int ego, double * currentValues);
};

}

#endif /*SONADAINONLYEFFECT_H_*/
