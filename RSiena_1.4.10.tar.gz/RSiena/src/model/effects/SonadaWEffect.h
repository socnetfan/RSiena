/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: SonadaWEffect.h
 *
 * Description: This file contains the definition of the
 * SonadaWEffect class.
 *****************************************************************************/

#ifndef SONADAWEFFECT_H_
#define SONADAWEFFECT_H_

#include "DyadicCovariateAndNetworkBehaviorEffect.h"

namespace siena
{

/**
 * This class implements several behavior effects related to similarity weighted by a dyadic covariate W
 * (see manual):
 * - Sonada similarity weighted by W
 * - Sonada similarity x popularity alter weighted by W
 * - Currently, the interactions with popularity are not in the EffectFactory.
 * - if those are going to be implemented, note what must be done with totalWeightValue
 */
class SonadaWEffect : public DyadicCovariateAndNetworkBehaviorEffect
{
public:
	SonadaWEffect(const EffectInfo * pEffectInfo,
		bool average,
		bool alterPopularity,
		bool egoPopularity);

	virtual double calculateChangeContribution(int actor,
		int difference);
	virtual double egoStatistic(int ego, double * currentValues);

private:
	bool laverage;
	bool lalterPopularity;
	bool legoPopularity;
	// lpar2 specifies that the internal effect parameter is 2
	bool lpar2;
};

}

#endif /*SONADAWEFFECT_H_*/
