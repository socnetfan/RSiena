/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: Sonada2mEffect.cpp
 *
 * Description: This file contains the implementation of the
 * Sonada2mEffect class.
 *****************************************************************************/
#include <cmath>
#include <cstdlib>
#include "Sonada2mEffect.h"
#include "data/Data.h"
#include "network/Network.h"
#include "network/IncidentTieIterator.h"
#include "model/EffectInfo.h"
#include "model/variables/BehaviorVariable.h"

namespace siena
{

/**
 * Constructor.
 * @param[in] average indicates if one of the average effects is required
 * @param[in] alterPopularity indicates if the similarity scores have to
 * be multiplied by the in-degrees of alters
 */
Sonada2mEffect::Sonada2mEffect(
	const EffectInfo * pEffectInfo) :
		DyadicCovariateAndNetworkBehaviorEffect(pEffectInfo)
{
}


/**
 * Calculates the change in the statistic corresponding to this effect if
 * the given actor would change his behavior by the given amount.
 */
double Sonada2mEffect::calculateChangeContribution(int actor,
	int difference)
{
	double contribution = 0;

	double oldValue = this->value(actor);
    double newValue = oldValue + difference;
	double totalChange = 0;
	double neighborCount = 0;
	double change = 0;
	for (int a = 0; a < this->pNetwork()->n(); a++)
	{
		int alterValue = this->value(a);
		double dycova = this->dycoValue(actor, a);
		change = dycova * (abs(oldValue - alterValue) - abs(newValue - alterValue));
		if (dycova != 0.0) 	neighborCount++;
		totalChange += change;
	}		
	contribution = totalChange;
/**
    contribution = totalChange/neighborCount;
*/	
	return contribution;
}


/**
 * Returns the statistic corresponding to the given ego with respect to the
 * given values of the behavior variable.
 */
double Sonada2mEffect::egoStatistic(int ego,
	double * currentValues)
{

	double statistic = 0;
	double tt = 0;
	double neighborCount = 0;

	for (int a = 0; a < this->pNetwork()->n(); a++)
	{
		double dycova = this->dycoValue(ego, a);
		if (currentValues[ego] > currentValues[a])
		{
		    tt = dycova * (currentValues[a]-currentValues[ego]);
	    }
		else
		{
		    tt = dycova * (currentValues[ego]-currentValues[a]);
		}
		statistic += tt;
        if (dycova != 0.0) neighborCount++;
		
	}
/**
    statistic /= neighborCount;	
*/	
	return statistic;
}

}
