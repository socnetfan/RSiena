/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: SonadaOutOnlyEffect.h
 *
 * Description: This file contains the definition of the
 * SonadaOutOnlyEffect class.
 *****************************************************************************/

#ifndef SONADAOUTONLYEFFECT_H_
#define SONADAOUTONLYEFFECT_H_

#include "NetworkDependentBehaviorEffect.h"

namespace siena
{

/**
 * This class implements several behavior effects related to similarity
 * (see manual):
 * - Sonada Unrecip similarity
 */
class SonadaOutOnlyEffect : public NetworkDependentBehaviorEffect
{
public:
	SonadaOutOnlyEffect(const EffectInfo * pEffectInfo);

	virtual double calculateChangeContribution(int actor,
		int difference);
	virtual double egoEndowmentStatistic(int ego, const int * difference,
		double * currentValues);
	virtual double egoStatistic(int ego, double * currentValues);
};

}

#endif /*SONADAOUTONLYEFFECT_H_*/
