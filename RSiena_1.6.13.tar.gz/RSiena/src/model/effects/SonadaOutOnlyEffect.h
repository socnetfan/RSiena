/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 * File: SonadaOutOnlyEffect.h
 * Non-reciprocal outgoing SONADA: ego -> alter, alter -/-> ego.
 *****************************************************************************/
#ifndef SONADAOUTONLYEFFECT_H_
#define SONADAOUTONLYEFFECT_H_

#include "NetworkDependentBehaviorEffect.h"

namespace siena
{
class Network;

class SonadaOutOnlyEffect : public NetworkDependentBehaviorEffect
{
public:
	SonadaOutOnlyEffect(const EffectInfo * pEffectInfo,
		bool average, bool alterPopularity, bool egoPopularity);

	virtual double calculateChangeContribution(int actor, int difference);
	virtual double egoEndowmentStatistic(int ego,
		const int * difference, double * currentValues);
	virtual double egoStatistic(int ego, double * currentValues);

private:
	bool laverage;
	bool lalterPopularity;
	bool legoPopularity;

	int outOnlyCount(const Network * pNetwork, int ego) const;
};
}
#endif
