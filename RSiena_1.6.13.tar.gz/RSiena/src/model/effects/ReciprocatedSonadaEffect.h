/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 * File: ReciprocatedSonadaEffect.h
 * Reciprocated SONADA: ego -> alter AND alter -> ego.
 *****************************************************************************/
#ifndef RECIPROCATEDSONADAEFFECT_H_
#define RECIPROCATEDSONADAEFFECT_H_

#include "NetworkDependentBehaviorEffect.h"

namespace siena
{
class Network;

class ReciprocatedSonadaEffect : public NetworkDependentBehaviorEffect
{
public:
	ReciprocatedSonadaEffect(const EffectInfo * pEffectInfo,
		bool average, bool alterPopularity, bool egoPopularity);

	virtual double calculateChangeContribution(int actor, int difference);
	virtual double egoEndowmentStatistic(int ego,
		const int * difference, double * currentValues);
	virtual double egoStatistic(int ego, double * currentValues);

private:
	bool laverage;
	bool lalterPopularity;
	bool legoPopularity;

	int reciprocatedCount(const Network * pNetwork, int ego) const;
};
}
#endif
