/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 * File: SonadaInOnlyEffect.h
 * Non-reciprocal incoming SONADA: alter -> ego, ego -/-> alter.
 *****************************************************************************/
#ifndef SONADAINONLYEFFECT_H_
#define SONADAINONLYEFFECT_H_

#include "NetworkDependentBehaviorEffect.h"

namespace siena
{
class Network;

class SonadaInOnlyEffect : public NetworkDependentBehaviorEffect
{
public:
	SonadaInOnlyEffect(const EffectInfo * pEffectInfo,
		bool average, bool alterPopularity, bool egoPopularity);

	virtual double calculateChangeContribution(int actor, int difference);
	virtual double egoEndowmentStatistic(int ego,
		const int * difference, double * currentValues);
	virtual double egoStatistic(int ego, double * currentValues);

private:
	bool laverage;
	bool lalterPopularity;
	bool legoPopularity;

	int inOnlyCount(const Network * pNetwork, int ego) const;
};
}
#endif
