/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 * File: ReciprocatedSonadaEffect.cpp
 *
 * Average statistic:
 * s_i^R = -(1/n_i^R) sum_j x_ij x_ji |z_i-z_j|.
 *
 * Defensive rule:
 * Network::tieValue() is required to return only 0 or 1 here.
 * Any other value triggers a runtime error.
 *****************************************************************************/

#include <cstdlib>
#include <cmath>
#include <stdexcept>

#include "ReciprocatedSonadaEffect.h"
#include "network/Network.h"
#include "network/IncidentTieIterator.h"
#include "model/variables/NetworkVariable.h"
#include "model/variables/BehaviorVariable.h"

using namespace std;

namespace siena
{

static int checkedTieValueRecip(
	const Network * pNetwork,
	int ego,
	int alter)
{
	int value = pNetwork->tieValue(ego, alter);

	if (value != 0 && value != 1)
	{
		throw runtime_error(
			"ReciprocatedSonadaEffect encountered a network tie value other "
			"than 0 or 1.");
	}

	return value;
}


ReciprocatedSonadaEffect::ReciprocatedSonadaEffect(
	const EffectInfo * pEffectInfo,
	bool average,
	bool alterPopularity,
	bool egoPopularity) :
		NetworkDependentBehaviorEffect(pEffectInfo)
{
	this->laverage = average;
	this->lalterPopularity = alterPopularity;
	this->legoPopularity = egoPopularity;
}


int ReciprocatedSonadaEffect::reciprocatedCount(
	const Network * pNetwork,
	int ego) const
{
	int count = 0;

	for (IncidentTieIterator iter = pNetwork->outTies(ego);
		 iter.valid();
		 iter.next())
	{
		int j = iter.actor();

		// outTies() guarantees ego -> j.
		// Verify reverse tie and retain only reverse == 1.
		int reverse = checkedTieValueRecip(pNetwork, j, ego);

		if (reverse == 1)
		{
			count++;
		}
	}

	return count;
}


double ReciprocatedSonadaEffect::calculateChangeContribution(
	int actor,
	int difference)
{
	const Network * pNetwork = this->pNetwork();

	if (!pNetwork->isOneMode())
	{
		throw runtime_error(
			"ReciprocatedSonadaEffect requires a one-mode network.");
	}

	int neighborCount =
		this->reciprocatedCount(pNetwork, actor);

	if (neighborCount == 0)
	{
		return 0;
	}

	int oldValue = this->value(actor);
	int newValue = oldValue + difference;
	int totalChange = 0;

	for (IncidentTieIterator iter = pNetwork->outTies(actor);
		 iter.valid();
		 iter.next())
	{
		int j = iter.actor();
		int reverse = checkedTieValueRecip(pNetwork, j, actor);

		if (reverse == 0)
		{
			continue;
		}

		int alterValue = this->value(j);

		int change =
			abs(oldValue - alterValue) -
			abs(newValue - alterValue);

		if (this->lalterPopularity)
		{
			change *= pNetwork->inDegree(j);
		}

		totalChange += change;
	}

	double contribution = totalChange;

	if (this->laverage)
	{
		contribution =
			((double) totalChange) / neighborCount;
	}

	if (this->legoPopularity)
	{
		contribution *= pNetwork->inDegree(actor);
	}

	return contribution;
}


double ReciprocatedSonadaEffect::egoStatistic(
	int ego,
	double * currentValues)
{
	const Network * pNetwork = this->pNetwork();

	if (!pNetwork->isOneMode())
	{
		throw runtime_error(
			"ReciprocatedSonadaEffect requires a one-mode network.");
	}

	double statistic = 0;
	int neighborCount = 0;

	for (IncidentTieIterator iter = pNetwork->outTies(ego);
		 iter.valid();
		 iter.next())
	{
		int j = iter.actor();
		int reverse = checkedTieValueRecip(pNetwork, j, ego);

		if (reverse == 0)
		{
			continue;
		}

		if (!this->missing(this->period(), j) &&
			!this->missing(this->period() + 1, j))
		{
			double tt =
				-fabs(currentValues[ego] - currentValues[j]);

			if (this->lalterPopularity)
			{
				tt *= pNetwork->inDegree(j);
			}

			statistic += tt;
			neighborCount++;
		}
	}

	if (this->laverage && neighborCount > 0)
	{
		statistic /= neighborCount;
	}

	if (this->legoPopularity)
	{
		statistic *= pNetwork->inDegree(ego);
	}

	return statistic;
}


double ReciprocatedSonadaEffect::egoEndowmentStatistic(
	int ego,
	const int * difference,
	double * currentValues)
{
	if (this->lalterPopularity)
	{
		throw runtime_error(
			string("endowmentStatistic not implemented for ") +
			"ReciprocatedSonadaEffect x alter popularity.");
	}

	const Network * pNetwork = this->pNetwork();

	if (!pNetwork->isOneMode())
	{
		throw runtime_error(
			"ReciprocatedSonadaEffect requires a one-mode network.");
	}

	double statistic = 0;

	if (!this->missing(this->period(), ego) &&
		!this->missing(this->period() + 1, ego) &&
		difference[ego] > 0)
	{
		double thisStatistic = 0;
		int neighborCount = 0;

		for (IncidentTieIterator iter = pNetwork->outTies(ego);
			 iter.valid();
			 iter.next())
		{
			int j = iter.actor();
			int reverse = checkedTieValueRecip(pNetwork, j, ego);

			if (reverse == 0)
			{
				continue;
			}

			if (!this->missing(this->period(), j) &&
				!this->missing(this->period() + 1, j))
			{
				double alterValue = currentValues[j];

				thisStatistic +=
					iter.value() *
					(0.0 - fabs(alterValue - currentValues[ego]));

				neighborCount++;
			}
		}

		if (this->laverage && neighborCount > 0)
		{
			thisStatistic /= neighborCount;
		}

		if (this->legoPopularity)
		{
			thisStatistic *= pNetwork->inDegree(ego);
		}

		statistic = thisStatistic;
		thisStatistic = 0;

		for (IncidentTieIterator iter = pNetwork->outTies(ego);
			 iter.valid();
			 iter.next())
		{
			int j = iter.actor();
			int reverse = checkedTieValueRecip(pNetwork, j, ego);

			if (reverse == 0)
			{
				continue;
			}

			if (!this->missing(this->period(), j) &&
				!this->missing(this->period() + 1, j))
			{
				double alterValue =
					currentValues[j] + difference[j];

				thisStatistic +=
					iter.value() *
					(0.0 -
					 fabs(alterValue -
						  (difference[ego] + currentValues[ego])));
			}
		}

		if (this->laverage && neighborCount > 0)
		{
			thisStatistic /= neighborCount;
		}

		if (this->legoPopularity)
		{
			thisStatistic *= pNetwork->inDegree(ego);
		}

		statistic -= thisStatistic;
	}

	return statistic;
}

}
