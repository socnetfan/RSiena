/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: SonadaOutOnlyEffect.cpp
 *
 * Description: This file contains the implementation of the
 * SonadaOutOnlyEffect class.
 *****************************************************************************/
#include <cstdlib>
#include <cmath>
#include <stdexcept>
#include "SonadaOutOnlyEffect.h"
#include "network/Network.h"
#include "network/IncidentTieIterator.h"
#include "network/OneModeNetwork.h"
#include "network/CommonNeighborIterator.h"
#include "model/variables/NetworkVariable.h"
#include "model/variables/BehaviorVariable.h"

using namespace std;

namespace siena
{

/**
 * Constructor.
 * @param[in] average indicates if one of the average effects is required
 * @param[in] alterPopularity indicates if the similarity scores have to
 * be multiplied by the in-degrees of alters
 */
SonadaOutOnlyEffect::SonadaOutOnlyEffect(const EffectInfo * pEffectInfo) :
		NetworkDependentBehaviorEffect(pEffectInfo)
{
}

/**
 * Calculates the change in the statistic corresponding to this effect if
 * the given actor would change his behavior by the given amount.
 */
double SonadaOutOnlyEffect::calculateChangeContribution(int actor,
	int difference)
{
	double contribution = 0;
	const Network * pNetwork1 = this->pNetwork();
	const OneModeNetwork * pNetwork2 =
		dynamic_cast<const OneModeNetwork *>(this->pNetwork());

	if (pNetwork1->outDegree(actor) > 0)
	{
		// The formula for the effect:
		// s_i(x) = -1 * abs(v_i - v_j) over all neighbors j of i.
		// We need to calculate the change delta in s_i(x), if we changed
		// v_i to v_i + d (d being the given amount of change in v_i).
		// This is abs(v_i - v_j)-abs(v_i + d - v_j).
		// This is what is calculated below.

		int oldValue = this->value(actor);
		int newValue = oldValue + difference;
		int totalChange = 0;
		int outcount = 0;
		int count = 0;

		for (IncidentTieIterator iter = pNetwork1->outTies(actor);
			iter.valid();
			iter.next())
		{
			int j = iter.actor();
			count = 0;
			if (pNetwork2->reciprocalDegree(actor) > 0)
			{	
			    for (CommonNeighborIterator iter1 = pNetwork2->reciprocatedTies(actor);
			        iter1.valid();
			        iter1.next())
		        {
				    int j1 = iter1.actor();
				    if (j == j1) 
				    {
					    count++;
				    }	
			    }
			}
		    if (count == 0) 
            {
				outcount++;
			    int alterValue = this->value(j);
			    int change = abs(oldValue - alterValue) - abs(newValue - alterValue);

			    totalChange += change;
		    }
		}
		
		if (outcount >0)
		{
		    contribution = ((double) totalChange)/outcount;
		}
	}

	return contribution;
}


/**
 * Returns the statistic corresponding to the given ego with respect to the
 * given values of the behavior variable.
 */
double SonadaOutOnlyEffect::egoStatistic(int ego,
	double * currentValues)
{
	const Network * pNetwork1 = this->pNetwork();
	const OneModeNetwork * pNetwork2 =
		dynamic_cast<const OneModeNetwork *>(this->pNetwork());

	double statistic = 0;
	double tt = 0;
	double neighborCount = 0;
	int count = 0;

	if (pNetwork1->outDegree(ego) > 0)
	{	
	    for (IncidentTieIterator iter = pNetwork1->outTies(ego);
		     iter.valid();
		     iter.next())
	    {
		    int j = iter.actor();
		    count = 0;
		    if (pNetwork2->reciprocalDegree(ego) > 0)
		    {	
		        for (CommonNeighborIterator iter1 = pNetwork2->reciprocatedTies(ego);
		             iter1.valid();
		             iter1.next())
	            {
		            int j1 = iter1.actor();
			        if (j == j1) 
			        {
				        count++;
				    }	
		        }
	        }
		    if (count == 0) 
		    {
		        if (!this->missing(this->period(), j) &&
			        !this->missing(this->period() + 1, j))
		        {
		            if (currentValues[ego] > currentValues[j])
		            {
		                tt = currentValues[j]-currentValues[ego];
	                }
		            else
		            {
		                tt = currentValues[ego]-currentValues[j];
		            }	

			        statistic += tt;
			        neighborCount++;
		        }
		    }  
	    }
	}
	
	if (neighborCount > 0)
	{
		statistic /= neighborCount;
	}

	return statistic;
}


/**
 * Returns the statistic corresponding to the given ego as part of
 * the endowment function with respect to the initial values of a
 * behavior variable and the current values.
 */
double SonadaOutOnlyEffect::egoEndowmentStatistic(int ego, const int * difference,
	double * currentValues)
{

	double statistic = 0;
	const Network * pNetwork1 = this->pNetwork();
	const OneModeNetwork * pNetwork2 =
		dynamic_cast<const OneModeNetwork *>(this->pNetwork());

	if (!this->missing(this->period(), ego) &&
		!this->missing(this->period() + 1, ego))
	{
		if (difference[ego] > 0)
		{
			if (pNetwork1->outDegree(ego))
			{
				double thisStatistic = 0;
				int outcount =0;

				for (IncidentTieIterator iter = pNetwork1->outTies(ego);
					 iter.valid();
					 iter.next())
				{
					int j = iter.actor();
					int count = 0;
					if (pNetwork2->reciprocalDegree(ego) > 0) 
					{
						for (CommonNeighborIterator iter1 = pNetwork2->reciprocatedTies(ego);
					         iter1.valid();
					         iter1.next())
				        {
							int j1 = iter1.actor();
			                if (j == j1) 
			                {
				                 count++;
				            }	
						}	
					}	
					if (count == 0)
					{
					    if (!this->missing(this->period(), iter.actor()) &&
					        !this->missing(this->period() + 1, iter.actor()))
					    {
					        double alterValue = currentValues[iter.actor()];
					        thisStatistic += iter.value() *
					    	    (0.0 - fabs(alterValue - currentValues[ego]));
							outcount++;		
						}		
					}
				}
				
				if (outcount >0)
				{
     				statistic = thisStatistic/outcount;
				}

				// do the same using the current state plus difference
				// in i's value rather than current state and subtract it.
				// not sure whether this is correct.

				thisStatistic = 0;
				outcount = 0;

				for (IncidentTieIterator iter = pNetwork1->outTies(ego);
					 iter.valid();
					 iter.next())
				{
					int j = iter.actor();
					int count = 0;
					if (pNetwork2->reciprocalDegree(ego) > 0) 
					{
						for (CommonNeighborIterator iter1 = pNetwork2->reciprocatedTies(ego);
					         iter1.valid();
					         iter1.next())
				        {
							int j1 = iter1.actor();
			                if (j == j1) 
			                {
				                 count++;
				            }	
						}
                    }						
					if (count == 0)
					{
					    if (!this->missing(this->period(), iter.actor()) &&
					  	    !this->missing(this->period() + 1, iter.actor()))
					    {
					        double alterValue = currentValues[iter.actor()] +
					    	    difference[iter.actor()];
					        thisStatistic += iter.value() *
						        (0.0 - fabs(alterValue - (difference[ego] + currentValues[ego])));
							outcount++;	
						}		
					}
				}

				if (outcount >0)
				{
					statistic -= thisStatistic/outcount;
				}
			}
		}
	}
    
	return statistic;
}

}
