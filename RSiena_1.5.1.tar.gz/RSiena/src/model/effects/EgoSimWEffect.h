/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: EgoSimWEffect.h
 *
 * Description: This file contains the definition of the
 * EgoSimWEffect class.
 *****************************************************************************/

#ifndef EGOSIMWEFFECT_H_
#define EGOSIMWEFFECT_H_

#include "DyadicCovariateAndNetworkBehaviorEffect.h"

namespace siena
{

/**
 * This class implements the behavior effect related to ego similarity weighted by a dyadic covariate W
 */
class EgoSimWEffect : public DyadicCovariateAndNetworkBehaviorEffect
{
public:
	EgoSimWEffect(const EffectInfo * pEffectInfo);

	virtual double calculateChangeContribution(int actor,
		int difference);
	virtual double egoStatistic(int ego, double * currentValues);
	
private:
	// lpar2 specifies that the internal effect parameter is 2
	bool lpar2;
};

}

#endif /*EGOSIMWEFFECT_H_*/
