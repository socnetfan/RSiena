/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: SonadaEffect.h
 *
 * Description: This file contains the definition of the
 * SonadaEffect class.
 *****************************************************************************/

#ifndef SONADAEFFECT_H_
#define SONADAEFFECT_H_

#include "NetworkDependentBehaviorEffect.h"

namespace siena
{

/**
 * This class implements several behavior effects related to similarity
 * (see manual):
 * - Sonada similarity
 * - Sonada similarity x popularity alter
 * - Sonada similarity x popularity ego
 */
class SonadaEffect : public NetworkDependentBehaviorEffect
{
public:
	SonadaEffect(const EffectInfo * pEffectInfo,
		bool average,
		bool alterPopularity,
		bool egoPopularity);

	virtual double calculateChangeContribution(int actor,
		int difference);
	virtual double egoEndowmentStatistic(int ego, const int * difference,
		double * currentValues);
	virtual double egoStatistic(int ego, double * currentValues);

private:
	bool laverage;
	bool lalterPopularity;
	bool legoPopularity;
};

}

#endif /*SONADAEFFECT_H_*/
